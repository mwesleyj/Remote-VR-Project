package android.arch.core;

/* loaded from: classes.dex */
public final class R {
}
