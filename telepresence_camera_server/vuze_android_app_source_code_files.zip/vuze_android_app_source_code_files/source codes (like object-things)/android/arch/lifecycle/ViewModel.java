package android.arch.lifecycle;

/* loaded from: classes.dex */
public abstract class ViewModel {
    /* JADX INFO: Access modifiers changed from: protected */
    public void onCleared() {
    }
}
